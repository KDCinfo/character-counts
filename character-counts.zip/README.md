# character-counts

**A Chrome Extension**

* See how many characters are in a selection's range.
* The extension will also convert characters between ASCII (char), ASCII (int), &amp;&amp; 8-bit (Byte).

The 'character conversion' code can also be found:

* [CodePen](https://codepen.io/KeithDC/pen/aLyOjy)
* [GitHub Gist](https://gist.github.com/KDCinfo/be7b9dbd42c6cc3c0e4ae79bfae9ffb9)
